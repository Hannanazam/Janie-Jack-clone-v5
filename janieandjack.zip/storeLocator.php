<?php include('header.php') ?>


<section class="listing_page">
  <div class="padding_x_5_lg padding_0_sm">
    <div class="row">
      <div class="col-lg-3 col-md-3 col-sm-12">
        <?php include('sidenav.php') ?>
      </div>
      <div class="col-lg-9 col-md-9 col-sm-12 my-5">
       <img src="https://i1.adis.ws/i/janieandjack/052120_LP_Health_Desktop.webp?$banner_bar_desktop$&fmt=webp" alt="">
    </div>
  </div>
  </div>
</section>


<?php include('footer.php') ?>