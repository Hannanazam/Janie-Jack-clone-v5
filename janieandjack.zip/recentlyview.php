<div class="recently_view padding_x_5_lg padding_0_sm">
<div class="slider_section cards">
    <hr>
    <div class="text-center">
        <p>Recently View</p>
    </div>
          <div class="row">
            <div class="col-lg-3 col-md-4 col-sm-12">
              <div class="item">
                <a href="detail.php">
                <div class="slider_image">
                  <img class="card_img_top" src="https://i1.adis.ws/i/janieandjack/70120852_JJ/color?$PLP_main$" data-org="https://i1.adis.ws/i/janieandjack/70120852_JJ/color?$PLP_main$" data-img="https://i1.adis.ws/i/janieandjack/100040197_JJ/color?$PLP_main$" alt="">
                </div>
                <div class="card-body text-center"><a href="detail.php">
                  </a><a class="quickview small-link" href="">Quick Look</a>
                  <p class="card-text mb-1 mt-0">The Poplin Shirt</p>
                  <h5 class="card-title my-1"><del>PKR 7,726.84</del> <span class="text-danger">PKR 6,726.84</span></h5>
                  <span style="color:#3c759a;font-size:12px;">Sizes 3m-12yrs</span>

                  <div class="rate">
                    <input type="radio" id="star5" name="rate" value="5">
                    <label for="star5" title="text">5 stars</label>
                    <input type="radio" id="star4" name="rate" value="4">
                    <label for="star4" title="text">4 stars</label>
                    <input type="radio" id="star3" name="rate" value="3">
                    <label for="star3" title="text">3 stars</label>
                    <input type="radio" id="star2" name="rate" value="2">
                    <label for="star2" title="text">2 stars</label>
                    <input type="radio" id="star1" name="rate" value="1">
                    <label for="star1" title="text">1 star</label>
                  </div>

                </div>
                
                </a>
              
              </div>
            </div>

            <div class="col-lg-3 col-md-4 col-sm-12">
              <div class="item">
                <div class="slider_image">
                  <img class="card_img_top" src="https://i1.adis.ws/i/janieandjack/100040197_JJ/color?$PLP_main$" data-org="https://i1.adis.ws/i/janieandjack/70120852_JJ/color?$PLP_main$" data-img="https://i1.adis.ws/i/janieandjack/100040197_JJ/color?$PLP_main$" alt="">
                </div>
                <div class="card-body text-center">
                  <a class="quickview small-link" href="">Quick Look</a>
                  <p class="card-text mb-1 mt-0">The Poplin Shirt</p>
                  <h5 class="card-title my-1"><del>PKR 7,726.84</del> <span class="text-danger">PKR 6,726.84</span></h5>
                  <span style="color:#3c759a;font-size:12px;">Sizes 3m-12yrs</span>

                  <div class="rate">
                    <input type="radio" id="star5" name="rate" value="5">
                    <label for="star5" title="text">5 stars</label>
                    <input type="radio" id="star4" name="rate" value="4">
                    <label for="star4" title="text">4 stars</label>
                    <input type="radio" id="star3" name="rate" value="3">
                    <label for="star3" title="text">3 stars</label>
                    <input type="radio" id="star2" name="rate" value="2">
                    <label for="star2" title="text">2 stars</label>
                    <input type="radio" id="star1" name="rate" value="1">
                    <label for="star1" title="text">1 star</label>
                  </div>

                </div>
              </div>
            </div>

            
          </div>
        </div>
        </div>